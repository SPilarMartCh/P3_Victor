`timescale 1ns / 1ps
// ============================================================
// TESTBENCH - instancia top.sv y recorre la maquina completa.
// Se baja el prescaler (PSC_BIT = 2) para que la simulacion sea corta:
//   tick = 2^3 * 10 ns = 80 ns por ciclo de reloj lento.
// Cada paso se autoverifica: imprime OK o ERROR en la consola Tcl de Vivado.
// ============================================================
module testbench;

    // estimulos
    logic        CLK100MHZ = 0;
    logic        btnU = 0, btnC = 0, btnD = 0;
    logic [15:0] sw = 16'h0000;
    logic [15:0] LED;

    // nombres legibles para las salidas del top
    wire [1:0] credito = LED[1:0];
    wire       V       = LED[2];
    wire       Tp      = LED[3];
    wire       E       = LED[4];
    wire       M1      = LED[8];
    wire       M2      = LED[9];
    wire       Puerta  = LED[10];
    wire       Busy    = LED[11];
    wire [1:0] estado  = LED[13:12];   // 00 R, 01 SP, 10 ES, 11 EN

    // dispositivo bajo prueba
    top #(.PSC_BIT(2)) dut (.CLK100MHZ(CLK100MHZ), .btnU(btnU), .btnC(btnC),
                            .btnD(btnD), .sw(sw), .LED(LED));

    // reloj de 100 MHz
    always #5 CLK100MHZ = ~CLK100MHZ;

    // reloj lento interno (para sincronizar los estimulos)
    wire clk_slow = dut.clk_slow;

    integer errores = 0;
    logic   v_vista, tp_vista, e_vista;   // salidas Mealy capturadas durante la compra

    // ---------- tareas ----------
    task automatic ciclos(input int n);
        repeat (n) @(negedge clk_slow);
    endtask

    task automatic moneda;
        btnU = 1; ciclos(2); btnU = 0; ciclos(1);
    endtask

    // presiona comprar y captura V, Tp y E en el ciclo del pulso
    task automatic comprar(input logic tipo);
        sw[0] = tipo;
        btnC = 1;
        @(posedge clk_slow); #1;              // aqui el pulso K ya esta activo
        v_vista = V; tp_vista = Tp; e_vista = E;
        ciclos(2); btnC = 0; ciclos(1);
    endtask

    task automatic sensor(input logic f);
        sw[1] = f; ciclos(2);
    endtask

    task automatic revisa(input string paso, input logic cond);
        if (cond) $display("[%t] OK    %s", $time, paso);
        else begin
            $display("[%t] ERROR %s  (credito=%0d V=%b Tp=%b E=%b estado=%b M1=%b M2=%b Puerta=%b Busy=%b)",
                     $time, paso, credito, v_vista, tp_vista, e_vista, estado, M1, M2, Puerta, Busy);
            errores++;
        end
    endtask

    // ---------- secuencia de prueba ----------
    initial begin
        $timeformat(-9, 0, " ns", 8);
        $dumpfile("testbench.vcd");
        $dumpvars(0, testbench);

        btnD = 1; #200; btnD = 0; ciclos(2);
        revisa("1. Reset: credito 0$, Moore en R", credito == 0 && estado == 2'b00 && !Busy);

        comprar(0);
        revisa("2. Comprar simple con 0$ -> E=1, no vende", e_vista && !v_vista && credito == 0);

        moneda;
        revisa("3. Moneda -> credito 1$", credito == 1);

        comprar(0);
        revisa("4. Comprar simple con 1$ -> V=1, Tp=0", v_vista && !tp_vista && !e_vista);
        revisa("   credito baja a 0$ y Moore pasa a SP (M1=1, Busy=1)",
               credito == 0 && estado == 2'b01 && M1 && Busy);

        moneda; moneda;
        revisa("5. Dos monedas con el mecanismo ocupado -> credito 2$", credito == 2);

        comprar(1);
        revisa("6. Comprar mientras Busy=1 -> se ignora, credito sigue en 2$",
               !v_vista && !e_vista && credito == 2);

        sensor(1);
        revisa("7. F=1 (cayo el pastelito) -> EN, Puerta=1", estado == 2'b11 && Puerta && !M1);
        sensor(0);
        revisa("8. F=0 (lo retiraron) -> R, Busy=0", estado == 2'b00 && !Busy);

        comprar(1);
        revisa("9. Comprar especial con 2$ -> V=1, Tp=1", v_vista && tp_vista && !e_vista);
        revisa("   credito 0$ y Moore pasa a ES (M2=1)", credito == 0 && estado == 2'b10 && M2);
        sensor(1); sensor(0);
        revisa("10. Entrega especial completa -> regreso a R", estado == 2'b00);

        moneda; moneda; moneda; moneda;
        revisa("11. Cuatro monedas -> credito topa en 3$", credito == 3);

        comprar(1);
        revisa("12. Comprar especial con 3$ -> vende y queda 1$", v_vista && tp_vista && credito == 1);
        sensor(1); sensor(0);

        comprar(1);
        revisa("13. Comprar especial con 1$ -> E=1, credito sigue en 1$", e_vista && !v_vista && credito == 1);

        comprar(0);
        revisa("14. Comprar simple con 1$ -> vende y queda 0$", v_vista && !tp_vista && credito == 0);
        sensor(1); sensor(0);

        if (errores == 0) $display("\n*** SIMULACION EXITOSA: todas las pruebas pasaron ***");
        else              $display("\n*** %0d PRUEBAS FALLARON ***", errores);
        $finish;
    end

endmodule
