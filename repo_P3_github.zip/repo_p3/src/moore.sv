`timescale 1ns / 1ps
// ============================================================
// Bloque 2 - MOORE: Mecanismo de entrega
//   Estados : R (00) reposo, SP (01) resorte simple,
//             ES (10) resorte especial, EN (11) entrega
//   Entradas: V (vender), Tp (tipo), F (sensor de bandeja)
//   Salidas : M1, M2, Puerta, Busy -> dependen SOLO del estado (Moore)
// ============================================================
module moore(input  logic       clk,
             input  logic       reset,
             input  logic       V, Tp, F,
             output logic       M1, M2, Puerta, Busy,
             output logic [1:0] estado);

    // variable sets
    typedef enum logic [1:0] {R  = 2'b00,
                              SP = 2'b01,
                              ES = 2'b10,
                              EN = 2'b11} statetype;
    statetype state, nextstate;

    // state register
    always_ff @(posedge clk, posedge reset)
        if (reset) state <= R;
        else       state <= nextstate;

    // next state logic
    always_comb
        case (state)
            R : if (V && Tp)  nextstate = ES;        // orden de venta, especial
                else if (V)   nextstate = SP;        // orden de venta, simple
                else          nextstate = R;
            SP: if (F) nextstate = EN;                // cayo el pastelito simple
                else   nextstate = SP;
            ES: if (F) nextstate = EN;                // cayo el pastelito especial
                else   nextstate = ES;
            EN: if (F) nextstate = EN;                // esperando que lo retiren
                else   nextstate = R;
            default:   nextstate = R;
        endcase

    // output logic (solo depende del estado)
    always_comb
        case (state)
            R : begin M1 = 0; M2 = 0; Puerta = 0; Busy = 0; end
            SP: begin M1 = 1; M2 = 0; Puerta = 0; Busy = 1; end
            ES: begin M1 = 0; M2 = 1; Puerta = 0; Busy = 1; end
            EN: begin M1 = 0; M2 = 0; Puerta = 1; Busy = 1; end
            default: begin M1 = 0; M2 = 0; Puerta = 0; Busy = 0; end
        endcase

    assign estado = state;

endmodule
