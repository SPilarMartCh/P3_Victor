`timescale 1ns / 1ps
// Divisor de reloj (igual al del ejemplo de clase, con el bit parametrizable).
// tick = bit BIT de un contador de 32 bits que avanza a 100 MHz.
//   BIT = 25 -> periodo de tick = 2^26 / 100 MHz = 0.67 s  (~1.5 Hz)
module clck_psc #(parameter int BIT = 25)
                (input  logic clk,
                 output logic tick);

    logic [31:0] myreg = 32'd0;   // valor inicial: lo respeta Vivado y la simulacion

    always_ff @(posedge clk)
        myreg <= myreg + 1;

    assign tick = myreg[BIT];
endmodule
