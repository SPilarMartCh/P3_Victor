`timescale 1ns / 1ps
// ============================================================
// Bloque 1 - MEALY: Credito y venta
//   Estado  : credito acumulado 0$..3$ (S1 S0)
//   Entradas: M (moneda 1$), K (comprar), T (0 = simple 1$, 1 = especial 2$),
//             B (mecanismo ocupado, viene de Busy del Moore)
//   Salidas : V (vender), Tp (tipo a entregar), E (error: credito insuficiente)
//   Las salidas dependen del estado Y de las entradas -> Mealy
// ============================================================
module mealy(input  logic       clk,
             input  logic       reset,
             input  logic       M, K, T, B,
             output logic       V, Tp, E,
             output logic [1:0] credito);

    // variable sets
    typedef enum logic [1:0] {C0 = 2'b00,   // 0$
                              C1 = 2'b01,   // 1$
                              C2 = 2'b10,   // 2$
                              C3 = 2'b11}   // 3$ (tope)
                              statetype;
    statetype state, nextstate;

    // senales auxiliares (decodificacion de entradas)
    logic moneda, compra;
    assign moneda = M & ~K;          // entra moneda (M=1 y K=1 a la vez = don't care -> se ignora)
    assign compra = K & ~M & ~B;     // compra valida solo si el mecanismo esta libre

    // state register
    always_ff @(posedge clk, posedge reset)
        if (reset) state <= C0;
        else       state <= nextstate;

    // next state logic
    always_comb begin
        nextstate = state;                       // por defecto: conservo el credito
        if (moneda)
            case (state)
                C0: nextstate = C1;
                C1: nextstate = C2;
                C2: nextstate = C3;
                C3: nextstate = C3;              // tope de 3$
            endcase
        else if (compra) begin
            if (!T)                              // simple: cuesta 1$
                case (state)
                    C1: nextstate = C0;
                    C2: nextstate = C1;
                    C3: nextstate = C2;
                    default: nextstate = state;  // C0: no alcanza
                endcase
            else                                 // especial: cuesta 2$
                case (state)
                    C2: nextstate = C0;
                    C3: nextstate = C1;
                    default: nextstate = state;  // C0, C1: no alcanza
                endcase
        end
    end

    // output logic (Mealy: estado + entradas)
    always_comb begin
        V = 1'b0; Tp = 1'b0; E = 1'b0;
        if (compra) begin
            if (!T) begin                        // simple
                if (state != C0) V = 1'b1;
                else             E = 1'b1;
            end else begin                       // especial
                if (state == C2 || state == C3) begin V = 1'b1; Tp = 1'b1; end
                else                                  E = 1'b1;
            end
        end
    end

    assign credito = state;

endmodule
