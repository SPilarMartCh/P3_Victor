`timescale 1ns / 1ps
// ============================================================
// TOP - Expendedora de pastelitos (Basys3)
//   Instancia el prescaler, la FSM Mealy (credito) y la FSM Moore (entrega)
//
//   Entradas de la tarjeta          Salidas (LEDs)
//   btnU  = M  moneda 1$            LED[1:0]   credito (C1 C0)
//   btnC  = K  comprar              LED[2]     V   vender
//   sw[0] = T  0 simple / 1 especial LED[3]    Tp  tipo entregado
//   sw[1] = F  sensor de bandeja    LED[4]     E   error
//   btnD  = reset                   LED[8]     M1  motor simple
//                                   LED[9]     M2  motor especial
//                                   LED[10]    Puerta
//                                   LED[11]    Busy
//                                   LED[13:12] estado Moore
//                                   LED[15]    reloj lento (tick)
// ============================================================
module top #(parameter int PSC_BIT = 25)       // en el testbench se baja para simular rapido
           (input  logic        CLK100MHZ,
            input  logic        btnU, btnC, btnD,
            input  logic [15:0] sw,
            output logic [15:0] LED);

    // ---------- reloj lento ----------
    logic clk_slow;
    clck_psc #(.BIT(PSC_BIT)) my_clck (.clk(CLK100MHZ), .tick(clk_slow));

    // ---------- botones -> un pulso de 1 ciclo ----------
    // Sin esto, mantener presionado el boton contaria varias monedas.
    logic m_s, m_d, k_s, k_d;
    always_ff @(posedge clk_slow, posedge btnD)
        if (btnD) begin m_s <= 0; m_d <= 0; k_s <= 0; k_d <= 0; end
        else begin
            m_s <= btnU;  m_d <= m_s;
            k_s <= btnC;  k_d <= k_s;
        end

    logic M, K;
    assign M = m_s & ~m_d;     // flanco de subida del boton moneda
    assign K = k_s & ~k_d;     // flanco de subida del boton comprar

    // ---------- senales entre las dos FSM ----------
    logic V, Tp, E, Busy;
    logic M1, M2, Puerta;
    logic [1:0] credito, estado_moore;

    mealy credito_venta (.clk(clk_slow), .reset(btnD),
                         .M(M), .K(K), .T(sw[0]), .B(Busy),
                         .V(V), .Tp(Tp), .E(E), .credito(credito));

    moore entrega       (.clk(clk_slow), .reset(btnD),
                         .V(V), .Tp(Tp), .F(sw[1]),
                         .M1(M1), .M2(M2), .Puerta(Puerta), .Busy(Busy),
                         .estado(estado_moore));

    // ---------- LEDs ----------
    assign LED[1:0]   = credito;
    assign LED[2]     = V;
    assign LED[3]     = Tp;
    assign LED[4]     = E;
    assign LED[7:5]   = 3'b000;
    assign LED[8]     = M1;
    assign LED[9]     = M2;
    assign LED[10]    = Puerta;
    assign LED[11]    = Busy;
    assign LED[13:12] = estado_moore;
    assign LED[14]    = 1'b0;
    assign LED[15]    = clk_slow;

endmodule
